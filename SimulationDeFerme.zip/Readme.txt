Je suppose qu'on veut imprimer la liste de tous les animaux seulement au début.
Je suppose qu'on veut imprimer la liste des animaux qui sont disponibles à manger ou à arrêter de manger lorsqu'on est dans le bon contexte.
Je suppose que plusieurs animaux peuvent consommer le foin en même temps.
Je suppose qu'on ne veut pas imprimer à la console ce qu'un animal a consommé pendant que l'animal mange (pas de print à chaque seconde).
Je suppose qu'on veut afficher à la console lorsqu'un animal a fini de manger (soit, car il ne peut plus manger de foin soit, car on l'a ordonné)
Je suppose qu'on veut afficher à la console lorsqu'un animal est ordonné à manger ou est ordonné à arrêter.

Note: en faisant cet exercice, je me suis rendu compte des mauvaises réponses que je vous ai données lors de l'entrevue.
Comme le fait qu'une classe PEUT hériter de 2 interfaces.
Comme mon explication du principe de synchronisation.
Et d'autres :).

